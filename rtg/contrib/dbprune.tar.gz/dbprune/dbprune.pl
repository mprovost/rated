#!/usr/bin/perl 
##
# Copyright (C) 2003  Josh Richard
# University of Minnesota - Duluth
# 
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##
# RTG SCHEMA for a given switch:
#
#+-------------------+
#| ifInOctets_id     |
#| ifOutOctets_id    |
#| ifInUcastPkts_id  |
#| ifOutUcastPkts_id |
#| interface         |
#| router            |
#+-------------------+

use DBI;

# clear the screen
system("/usr/bin/clear");

# set to 1 for verbosity.
my $debug = 1;
print "debug mode is on\n" if $debug;

# reset path and set shell for security
$ENV{PATH} = '';   
$ENV{SHELL} = '/bin/sh' if exists $ENV{SHELL};
delete @ENV{qw(IFS CDPATH ENV BASH_ENV)};

#connect to the database
my $rtgdbh =  dbConnect();

# Interactive is disabled by default...
my $interactive = 0;

# auto run enabled by default...
my $auto = 1;

# counter
my $counter = 0;

# Other variables
my ($rid, $name);

# preservation hash
my %preserve;

#get the n value:
print "Enter the number of days of history you which to keep: ";
my $n = <STDIN>;
chomp $n;
if (!($n =~ /\d/)){ die "You should have entered a number!\n";}

# delete data older than n days ago, let's set this up...
$query = "select curdate() - interval $n day";
my $sth0 = $rtgdbh->prepare($query);
if (!$sth0) { die "Error:" . $dbh->errstr . "\n";}
if (!$sth0->execute) { die "Error:" . $sth->errstr . "\n";}
my $dte = $sth0->fetchrow_array();
$sth0->finish();

my $start = "$dte 00:00:00";

# Tables to clean out...add more if needed in the future
my @tables = qw{ifInOctets_ ifOutOctets_ ifInUcastPkts_ ifOutUcastPkts_ ifInErrors_};
# Store a list of all tables in a hash for further processing
my %dbtables = {};

print "So, you want to delete data older than $start (y or n)? ";
my $input = <STDIN>;
chomp $input;

if ($input eq 'y'){
    print "Do you want to run this program interactively (y or n)? ";
    $input = <STDIN>;
    chomp $input;

    # set the interactive flag
    if ($input eq 'y'){ $interactive = 1; }
    #get the router names...
    my $query = "select name from router order by rid";
    my $sth  = $rtgdbh->prepare($query);
    if (!$sth) { die "Error:" . $dbh->errstr . "\n";}
    if (!$sth->execute) { die "Error:" . $sth->errstr . "\n";}

    # populate a hash of router names to exclude from pruning.
    prunePreserve(\%preserve);

    # setup a hash of table names to be used later.
    $query = 'show tables';
    my $sth3 = $rtgdbh->prepare($query);
    if (!$sth3) { die "Error:" . $dbh->errstr . "\n";}
    if (!$sth3->execute) { die "Error:" . $sth->errstr . "\n";}
    while (my $tab = $sth3->fetchrow_array()){
	$dbtables{$tab} = 1;
    }

    $sth3->finish();
    # for every switch, delete the interface data which is older than N days from now.
    while(my $dns = $sth->fetchrow_array()){ 

	# skip boxes specified in file...
	if (exists $preserve{$dns}){
	    print "Skipping $dns because it is in dbprune.preserve\n" if $debug;
	    next;
	}
	$counter++;
	if ($interactive ){
	    print "Do you want to clean out old data for $dns (y or n)? ";
	    $input = <STDIN>;
	    chomp $input;
	    next if $input ne 'y'; # go to the next router if non 'y' was entered
	}
	
	if ($input eq 'y' || $auto){
	    
	    print "Cleaning data older than $start for $dns:\n";

	    # get the rids
	    $query = "select distinct r.rid from router r, interface i where r.rid = i.rid and r.name = '$dns' order by r.rid";
	    my $sth2 = $rtgdbh->prepare($query);
	    if (!$sth2) { die "Error:" . $dbh->errstr . "\n";}
	    if (!$sth2->execute) { die "Error:" . $sth->errstr . "\n";}
	    my $rid = $sth2->fetchrow_array();
	    
	    foreach my $tab (@tables){
		# skip tables we are going to act on if they do not exist.
		if (exists $dbtables{"$tab$rid"}){
		    my $query = "delete from $tab$rid where $tab$rid.dtime < '$start'";
		    my $sth2 = $rtgdbh->prepare($query);
		    if (!$sth2) { die "Error:" . $dbh->errstr . "\n";}
		    if (!$sth2->execute) { die "Error:" . $sth->errstr . "\n";}
		    
		    # optimize the table to reclaim wasted MyISAM space:
		    print "\tOptimizing table $tab$rid...\n";
		    $query = "optimize table $tab$rid";
		    $sth2 = $rtgdbh->prepare($query);
		    if (!$sth2) { die "Error:" . $dbh->errstr . "\n";}
		    if (!$sth2->execute) { die "Error:" . $sth->errstr . "\n";}
		    
		    # clean up:
		    $sth2->finish();		
		} else {
		    print "It looks as though there is no $tab$rid for rid $rid...skipping\n" if $debug;
		}
	    }
	}
    }
    print "Processed $counter devices.\n";
# close stuff.
    $sth->finish();
    $rtgdbh->disconnect;

}else {
    print "bye\n";
}

####
#
## Subroutines
#
####

####
#
#
#
## prunePreserve
# 
#  no this is not a jar of prune juice ;)
#  This reads a config file and maintains a hash of router names which 
#  need to be skipped from the pruning process. 
#
####
sub prunePreserve{
    print "Subroutine prunePreserve:\n\n" if $debug; 
    print "\tThis reads a config file and maintains a hash of router names which\n" if $debug;
    print "\tneed to be skipped from the pruning process. \n\n" if $debug;
    my $hashref = $_[0];
    
    # get the dbprune.preserve file from the config directory:
    # Default locations to find dbprune.preserve configuration file
    my @configs = ("dbprune.preserve", "/usr/local/rtg/etc/dbprune.preserve", "/etc/dbprune.preserve");
    foreach $conf (@configs) {
        if (open CONF, "< $conf") {
	    print "\tReading [$conf] for history preservation.\n\n" if $debug;
	    print "\tStripping comments and blank lines...\n" if $debug;
	    while (<CONF>) {
		chomp;
		if(/^\s*\#/) {next;}        # skip comments
		if(/^\s*$/) {next;}         # skip blank lines
		print "\t".'Setting $hashref{'."$_} = 1\n" if $debug; 
		$hashref->{$_} = 1;
		}
	last;
	}
	close CONF;
    }
}

####
#
#
#
## dbConnect
# 
#  Connnects to the database and returns a database handle.
#
####
sub dbConnect{
    print "Subroutine dbConnect:\n\n" if $debug;
    print "\tConnnects to the database and returns a database handle.\n\n" if $debug;
    my ($host,$user,$pass,$db);
    # Thanks to the author of report.pl...
    # Default locations to find RTG configuration file
    my @configs = ("rtg.conf", "/usr/local/rtg/etc/rtg.conf", "/etc/rtg.conf");
    foreach my $conf (@configs) {
	if (open CONF, "<$conf") {
	    print "\tReading [$conf].\n" if $debug;
	    while ($line = <CONF>) {
		@cVals = split /\s+/, $line;
		if ($cVals[0] =~ /DB_Host/) { 
		    $host=$cVals[1];
		} elsif ($cVals[0] =~ /DB_User/) { 
		    $user=$cVals[1];
		} elsif ($cVals[0] =~ /DB_Pass/) { 
		    $pass=$cVals[1];
		} elsif ($cVals[0] =~ /DB_Database/) { 
		    $db=$cVals[1];
		}
	    }
	    last;
	}
    }
    my $driver = "mysql";
    my $dsn = "DBI:$driver:database=$db;host=$host";

    my $dbh=DBI->connect($dsn, $user, $pass,{RaiseError=>1,AutoCommit=>1})
                        or die  " Can not connect to $dsn\n";
    # AutoCommit=>1 means we want to autocommit our sql code and not rely
    # on transactions
    
    print "\tdatabase connection successful\n\n" if $debug;
    return $dbh;
}
####
#
## EOF
# 
####
